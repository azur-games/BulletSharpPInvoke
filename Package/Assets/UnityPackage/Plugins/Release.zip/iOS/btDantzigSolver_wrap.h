#include "main.h"

extern "C"
{
	EXPORT btDantzigSolver* btDantzigSolver_new();
}
