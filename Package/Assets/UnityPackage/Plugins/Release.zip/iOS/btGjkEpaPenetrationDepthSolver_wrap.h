#include "main.h"

extern "C"
{
	EXPORT btGjkEpaPenetrationDepthSolver* btGjkEpaPenetrationDepthSolver_new();
}
