#include "main.h"

extern "C"
{
	EXPORT btEmptyShape* btEmptyShape_new();
}
