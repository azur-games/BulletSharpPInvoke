#include "main.h"

extern "C"
{
	EXPORT btMinkowskiPenetrationDepthSolver* btMinkowskiPenetrationDepthSolver_new();
}
