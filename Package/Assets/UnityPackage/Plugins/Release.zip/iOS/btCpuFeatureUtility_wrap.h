#include "main.h"

extern "C"
{
	EXPORT int btCpuFeatureUtility_getCpuFeatures();
}
